/*Entrega 5
PROJETO: CONSERTO DE ELETRONICOS.
ALUNOS: Mariana Piva, Camilly Carvalho, Gabriel Carvalho e Wesley Nogueira.*/


#include<stdio.h>
#include<string.h>
#include<locale.h>

struct cadastro{
    int numeroficha;
    char nome[50];
    char telefone[15];
    char equipamento[30];
    char defeito[100];
    int ativo;
};

//Vetor do registro cadastro.
struct cadastro cadastro[15];
    int quantidade = 0;

//Fun��o: cadastra uma nova ficha no sistema.
void cadastrar(){
        cadastro[quantidade].numeroficha = quantidade + 1;
        printf("\nNumero da ficha: %d\n",cadastro[quantidade].numeroficha);
        cadastro[quantidade].ativo = 1;

        printf("Digite o nome: ");
        fgets(cadastro[quantidade].nome, 50, stdin);
            if(strlen(cadastro[quantidade].nome) < 4){
                printf("Nome n�o pode ficar em branco.");
                return;
            }

        printf("Digite o telefone: ");
        fgets(cadastro[quantidade].telefone, 15, stdin);
            if(strlen(cadastro[quantidade].telefone) < 9){
                printf("Telefone n�o pode ficar em branco.");
                return;
            }

        printf("Digite o equipamento: ");
        fgets(cadastro[quantidade].equipamento, 30, stdin);
            if(strlen(cadastro[quantidade].equipamento) < 2){
                printf("Equipamento n�o pode ficar em branco.");
                return;
            }

        printf("Digite o defeito: ");
        fgets(cadastro[quantidade].defeito, 100, stdin);
            if(strlen(cadastro[quantidade].defeito) < 2){
                printf("Defeito n�o pode ficar em branco.");
                return;
            }

        quantidade++;
}

//Fun��o: listar todas as fichas ativas.
void listar(){
   int i = 0;
     for(i = 0; i < 15; i++){
        if(cadastro[i].ativo == 1){
            printf("-----------------------------------");
            printf("\nO numero da ficha: %d\n", cadastro[i].numeroficha);
            printf("O nome do cliente: %s\n", cadastro[i].nome);
            printf("O telefone do cliente: %s\n", cadastro[i].telefone);
            printf("O equipamente do cliente: %s\n", cadastro[i].equipamento);
            printf("O defeito do equipamento: %s\n\n", cadastro[i].defeito);
        }
    }

}

//Fun��o: visualizar a informa��o de uma ficha espec�fica ao informar seu n�mero.
void pesquisar(){
     int ficha;

     printf("Digite a ficha: ");
     scanf("%d", &ficha);
     getchar();

        if(ficha >= 1 && ficha <= quantidade && cadastro[ficha-1].ativo == 1){
           printf("\n--- DADOS DA FICHA %d ---\n", ficha);
           printf("Nome: %s\n", cadastro[ficha-1].nome);
           printf("telefone: %s\n", cadastro[ficha-1].telefone);
           printf("Equipamento: %s\n", cadastro[ficha-1].equipamento);
           printf("Defeito: %s\n", cadastro[ficha-1].defeito);
        }
        else{
           printf("Ficha n�o encontrada!\n");
        }

}

//Fun��o: editar as informa��es de uma ficha existente.
void editar(){
    int ficha;

    printf("Digite a ficha que quer alterar: ");
    scanf("%d", &ficha);
    getchar();

    if(ficha >= 1 && ficha <= quantidade){
        printf("Atualize o nome: ");
        fgets(cadastro[ficha-1].nome, 50, stdin);

        printf("Atualize o telefone: ");
        fgets(cadastro[ficha-1].telefone, 15, stdin);

        printf("Digite o equipamento: ");
        fgets(cadastro[ficha-1].equipamento, 30, stdin);

        printf("Digite o defeito: ");
        fgets(cadastro[ficha-1].defeito, 100, stdin);

        printf("Ficha atualizada com sucesso!");
    }

      else{
        printf("Ficha n�o encontrada.");
      }

}

//Fun��o: excluir logicamente uma ficha.
void encerrarficha(){
    int ficha;

    printf("Digite a ficha que deseja encerrar: ");
    scanf("%d", &ficha);
    getchar();

    if(ficha >= 1 && ficha <= quantidade){
        cadastro[ficha-1].ativo = 0;
        printf("Ficha encerrada!");
    }
    else{
        printf("Ficha n�o encontrada.");
    }
}

//Fun��o: reativar ficha exclu�da logicamente.
void reativarficha(){
    int ficha;

    printf("Digite a ficha que deseja reativar: ");
    scanf("%d", &ficha);
    getchar();

    if(ficha >= 1 && ficha <= quantidade){
        cadastro[ficha-1].ativo = 1;
        printf("Ficha reativada!");
    }
    else{
        printf("Ficha n�o encontrada.");
    }
}

//Fun��o: informar a quantidade total de fichas e a quantidade de fichas ativas e inativas.
void estatistica(){
    int calculaativo = 0;
    int calculainativo = 0;
    int total = 0;
    int i = 0;

    for(i = 0; i < quantidade; i++){
        if(cadastro[i].ativo == 1){
            calculaativo = calculaativo + 1;
        }
            else{
                calculainativo = calculainativo + 1;
            }
    }
     total = calculaativo + calculainativo;
     printf("Quantidade total de fichas: ");
     printf("%d", total);

     printf("\nQuantidade de fichas ativas: ");
     printf("%d", calculaativo);

     printf("\nQuantidade de fichas inativas: ");
     printf("%d", calculainativo);
}

int main() {
        setlocale(LC_ALL, "Portuguese");

    int clique;

        do{
            printf("\n------- MENU ------- \n\n");
            printf("Clique 1 para CADASTRAR\n");
            printf("Clique 2 para PROCURAR\n");
            printf("Clique 3 para LISTAR\n");
            printf("Clique 4 para EDITAR\n");
            printf("Clique 5 para ENCERRAR FICHA\n");
            printf("Clique 6 para REATIVAR FICHA\n");
            printf("Clique 7 para ESTAT�STICAS\n");
            printf("Clique 0 para ENCERRAR PROGRAMA\n");
            printf("------------------------\n");
            printf("Clique: ");
            scanf("%d", &clique);
            getchar();

                switch(clique){
                    case 1:
                        if(quantidade > 14){
                            printf("Limite de registros atingido!");
                            break;
                        }
                        cadastrar();
                        break;

                    case 2:
                        pesquisar();
                        break;

                    case 3:
                        listar();
                        break;

                    case 4:
                        editar();
                        break;

                    case 5:
                        encerrarficha();
                        break;

                    case 6:
                        reativarficha();
                        break;

                    case 7:
                        estatistica();
                        break;

                    case 0:
                        break;

                    default:
                        printf("Op��o inexistente, digite novamente...\n\n");

                }


        } while(clique != 0);

}
