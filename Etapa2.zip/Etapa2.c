/*Entrega 2
PROJETO: CONSERTO DE ELETRONICOS.
ALUNOS: Mariana Piva, Camilly Carvalho, Gabriel Carvalho e Wesley Nogueira.*/


#include<stdio.h>
#include<string.h>
#include <locale.h>


struct cadastro{
    int numeroficha;
    char nome[50];
    char telefone[15];
    char equipamento[30];
    char defeito[100];
    int ativo;
};

struct cadastro cadastro[15];
    int quantidade = 0;

void cadastrar(){
        cadastro[quantidade].numeroficha = quantidade + 1;
        printf("\nNumero da ficha: %d\n",cadastro[quantidade].numeroficha);
        cadastro[quantidade].ativo = 1;

        printf("Digite o nome: ");
        scanf("%s", cadastro[quantidade].nome);

        printf("Digite o telefone: ");
        scanf("%s", cadastro[quantidade].telefone);

        printf("Digite o equipamento: ");
        scanf("%s", cadastro[quantidade].equipamento);

        printf("Digite o defeito: ");
        scanf("%s", cadastro[quantidade].defeito);

        quantidade++;
}

void listar(){
   int i = 0;
     for(i = 0; i < 15; i++){
        if(cadastro[i].ativo == 1){
            printf("-----------------------------------");
            printf("\nO numero da ficha: %d\n", cadastro[i].numeroficha);
            printf("O nome do cliente: %s\n", cadastro[i].nome);
            printf("O telefone do cliente: %s\n", cadastro[i].telefone);
            printf("O equipamente do cliente: %s\n", cadastro[i].equipamento);
            printf("O defeito do equipamento: %s\n\n", cadastro[i].defeito);
            printf("-----------------------------------");
            }
    }

}

int main() {
        setlocale(LC_ALL, "Portuguese");

    int clique, ficha;


        do{
            printf("\n------- MENU ------- \n\n");
            printf("Clique 1 para CADASTRAR\n");
            printf("Clique 2 para PROCURAR\n");
            printf("Clique 3 para LISTAR\n");
            printf("Clique 0 para ENCERRAR\n\n");
            printf("Clique: ");
                scanf("%d", &clique);

                switch(clique){
                    case 1:
                        if(quantidade>14){
                            printf("Limite de registros atingido!");
                            break;
                        }
                        cadastrar();
                        break;

                    case 2:
                        printf("Digite a ficha: ");
                        scanf("%d", &ficha);

                            if(ficha >= 1 && ficha <= quantidade){
                                printf("\n--- DADOS DA FICHA %d ---\n", ficha);
                                printf("Nome: %s\n", cadastro[ficha-1].nome);
                                printf("telefone: %s\n", cadastro[ficha-1].telefone);
                                printf("Equipamento: %s\n", cadastro[ficha-1].equipamento);
                                printf("Defeito: %s\n", cadastro[ficha-1].defeito);
                                }
                            else{
                                printf("Ficha nao encontrada!\n");
                            }
                        break;

                    case 3:
                        listar();
                        break;

                    case 0:
                        break;

                    default:
                        printf("Opcao inexistente, digite novamente...\n\n");

                }


}while(clique != 0);

}
