/*Entrega 3
PROJETO: CONSERTO DE ELETRONICOS.
ALUNOS: Mariana Piva, Camilly Carvalho, Gabriel Carvalho e Wesley Nogueira.*/


#include<stdio.h>
#include<string.h>
#include <locale.h>

struct cadastro{
    int numeroficha;
    char nome[50];
    char telefone[15];
    char equipamento[30];
    char defeito[100];
    int ativo;
};

struct cadastro cadastro[15];
    int quantidade = 0;

void cadastrar(){
        cadastro[quantidade].numeroficha = quantidade + 1;
        printf("\nNumero da ficha: %d\n",cadastro[quantidade].numeroficha);
        cadastro[quantidade].ativo = 1;

        printf("Digite o nome: ");
        //scanf("%s", cadastro[quantidade].nome);
        fgets(cadastro[quantidade].nome, 50, stdin);
            if(strlen(cadastro[quantidade].nome) < 4){
                printf("Nome n o pode ficar em branco.");
                return;
            }

        printf("Digite o telefone: ");
        //scanf("%s", cadastro[quantidade].telefone);
         fgets(cadastro[quantidade].telefone, 15, stdin);
            if(strlen(cadastro[quantidade].telefone) < 9){
                printf("Telefone n o pode ficar em branco.");
                return;
            }

        printf("Digite o equipamento: ");
        //scanf("%s", cadastro[quantidade].equipamento);
         fgets(cadastro[quantidade].equipamento, 30, stdin);
            if(strlen(cadastro[quantidade].equipamento) < 2){
                printf("Equipamento n o pode ficar em branco.");
                return;
            }

        printf("Digite o defeito: ");
        //scanf("%s", cadastro[quantidade].defeito);
        fgets(cadastro[quantidade].defeito, 100, stdin);
            if(strlen(cadastro[quantidade].defeito) < 2){
                printf("Defeito n o pode ficar em branco.");
                return;
            }

        quantidade++;
}

void listar(){
   int i = 0;
     for(i = 0; i < 15; i++){
        if(cadastro[i].ativo == 1){
            printf("-----------------------------------");
            printf("\nO numero da ficha: %d\n", cadastro[i].numeroficha);
            printf("O nome do cliente: %s\n", cadastro[i].nome);
            printf("O telefone do cliente: %s\n", cadastro[i].telefone);
            printf("O equipamente do cliente: %s\n", cadastro[i].equipamento);
            printf("O defeito do equipamento: %s\n\n", cadastro[i].defeito);
            printf("-----------------------------------");
            }
    }

}

void pesquisar(){
    int ficha;
     printf("Digite a ficha: ");
     scanf("%d", &ficha);
     getchar();

        if(ficha >= 1 && ficha <= quantidade){
           printf("\n--- DADOS DA FICHA %d ---\n", ficha);
           printf("Nome: %s\n", cadastro[ficha-1].nome);
           printf("telefone: %s\n", cadastro[ficha-1].telefone);
           printf("Equipamento: %s\n", cadastro[ficha-1].equipamento);
           printf("Defeito: %s\n", cadastro[ficha-1].defeito);
        }
        else{
           printf("Ficha nao encontrada!\n");
        }

}

void editar(){
    int ficha;

    printf("Digite a ficha que quer alterar: ");
    scanf("%d", &ficha);
    getchar();

    if(ficha >= 1 && ficha <= quantidade){
        printf("Atualize o nome: ");
        fgets(cadastro[ficha-1].nome, 50, stdin);

        printf("*****Formato:(DDD) 9999-9999*****\nAtualize o telefone: ");
        fgets(cadastro[ficha-1].telefone, 15, stdin);

        printf("Digite o equipamento: ");
        fgets(cadastro[ficha-1].equipamento, 30, stdin);

        printf("Digite o defeito: ");
        fgets(cadastro[ficha-1].defeito, 100, stdin);

        printf("Ficha atualizada com sucesso!");
    }

      else{
        printf("Ficha n o encontrada.");
      }

}

int main() {
        setlocale(LC_ALL, "Portuguese");

    int clique, ficha;


        do{
            printf("\n------- MENU ------- \n\n");
            printf("Clique 1 para CADASTRAR\n");
            printf("Clique 2 para PROCURAR\n");
            printf("Clique 3 para LISTAR\n");
            printf("Clique 4 para EDITAR\n");
            printf("Clique 0 para ENCERRAR\n\n");
            printf("Clique: ");
            scanf("%d", &clique);
            getchar();

                switch(clique){
                    case 1:
                        if(quantidade>14){
                            printf("Limite de registros atingido!");
                            break;
                        }
                        cadastrar();
                        break;

                    case 2:
                        pesquisar ();
                        break;

                    case 3:
                        listar();
                        break;

                    case 4:
                        editar();
                        break;

                    case 0:
                        break;

                    default:
                        printf("Opcao inexistente, digite novamente...\n\n");

                }


}while(clique != 0);

}
